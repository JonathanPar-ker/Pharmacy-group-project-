package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
// @author Edem Kwame Hodasi,Jonathan Parker-Donkor,Zowonu Elikplim Kwame,Ofosu Jedidiah,Maxwell Williams,Andrew Tay,Dennis Agbanyo
public class DrugDAO {
    // Method to add a new drug to the database
    public static void addDrug(String name, String description, int stock, int supplierId) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("INSERT INTO drug (name, description, stock, supplier_id) VALUES (?, ?, ?, ?)");
            ps.setString(1, name);
            ps.setString(2, description);
            ps.setInt(3, stock);
            ps.setInt(4, supplierId);
            ps.executeUpdate();
            System.out.println("Drug added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update the stock of an existing drug
    public static void updateDrugStock(int drugId, int newStock) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("UPDATE drug SET stock = ? WHERE drug_id = ?");
            ps.setInt(1, newStock);
            ps.setInt(2, drugId);
            ps.executeUpdate();
            System.out.println("Drug stock updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a drug from the database
    public static void deleteDrug(int drugId) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("DELETE FROM drug WHERE drug_id = ?");
            ps.setInt(1, drugId);
            ps.executeUpdate();
            System.out.println("Drug deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to search for drugs by name
    public static void searchDrugByName(String name) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM drug WHERE name LIKE ?");
            ps.setString(1, "%" + name + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("Drug ID: " + rs.getInt("drug_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Stock: " + rs.getInt("stock"));
                System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view all drugs and their suppliers
    public static void viewAllDrugsAndSuppliers() {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT drug.*, supplier.name AS supplier_name, supplier.location AS supplier_location FROM drug JOIN supplier ON drug.supplier_id = supplier.supplier_id");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("Drug ID: " + rs.getInt("drug_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Stock: " + rs.getInt("stock"));
                System.out.println("Supplier: " + rs.getString("supplier_name") + " (" + rs.getString("supplier_location") + ")");
                System.out.println();
            }
        } catch (SQLException e) {
        }
    }
    

    // Method to view the purchase history of a drug
    public static void viewPurchaseHistory(int drugId) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT purchase_history.*, customer.name AS customer_name, customer.contact_info FROM purchase_history JOIN customer ON purchase_history.customer_id = customer.customer_id WHERE drug_id = ? ORDER BY purchase_date");
            ps.setInt(1, drugId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("Purchase ID: " + rs.getInt("purchase_id"));
                System.out.println("Drug ID: " + rs.getInt("drug_id"));
                System.out.println("Customer: " + rs.getString("customer_name") + " (" + rs.getString("contact_info") + ")");
                System.out.println("Purchase Date: " + rs.getTimestamp("purchase_date"));
                System.out.println("Amount: $" + rs.getBigDecimal("amount"));
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
